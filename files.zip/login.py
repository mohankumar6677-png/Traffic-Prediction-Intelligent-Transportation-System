import os
from tkinter import *
from tkinter import messagebox
from PIL import ImageTk, Image
import tkinter as tk
import time
from random import shuffle
import PIL.Image

# ============================================================
# Traffic Prediction and Intelligent Transportation System
# Author: Mohan Kumar D
# Published: IJRPR Journal, Vol 6, Issue 3, March 2025
# ============================================================

winadmin = Tk()
winadmin.title("Traffic Time Saver")
winadmin.geometry('900x900')
winadmin['background'] = 'teal'

image1 = PIL.Image.open("3.jpg")
img = image1.resize((900, 900))
test = ImageTk.PhotoImage(img)

label1 = tk.Label(winadmin, image=test)
label1.image = test
label1.place(x=0, y=0)

Label(winadmin, text='Traffic Time Saver', font='verdana 15 bold').place(x=240, y=80)

Admin = Label(winadmin, text="Admin", bg="white", width=10, font='Verdana 10 bold')
Admin.place(x=200, y=150)

password = Label(winadmin, text="password", bg="white", width=10, font='Verdana 10 bold')
password.place(x=200, y=190)

# Entry Box
admin_var = StringVar()
password_var = StringVar()

admin_entry = Entry(winadmin, width=30, bg="silver", textvariable=admin_var)
admin_entry.place(x=400, y=150)

password_entry = Entry(winadmin, width=30, bg="silver", textvariable=password_var)
password_entry.place(x=400, y=190)

def act():
    x = admin_var.get()
    y = password_var.get()
    if x == "Admin" and y == "Admin":
        messagebox.showinfo("Success", "Login successfully")
        exec(open("dataupload.py").read())
    else:
        messagebox.showinfo("Error", "Login failed")

Button(winadmin, text="login", font='Verdana 10 bold', bg="blue", command=act).place(x=310, y=240)

winadmin.mainloop()
