import os
import tkinter as tk
import time
from random import shuffle
from tkinter import messagebox, filedialog
from PIL import ImageTk, Image
import PIL.Image
import cv2
import matplotlib.pyplot as plt
import cvlib as cv
from cvlib.object_detection import draw_bbox

# ============================================================
# Traffic Prediction and Intelligent Transportation System
# Author: Mohan Kumar D
# Published: IJRPR Journal, Vol 6, Issue 3, March 2025
# ============================================================

winadmin = tk.Tk()
winadmin.title("Traffic Time Saver")
winadmin.geometry('700x600')
winadmin['background'] = 'white'

image1 = PIL.Image.open("3.jpg")
img = image1.resize((900, 900))
test = ImageTk.PhotoImage(img)

label1 = tk.Label(winadmin, image=test)
label1.image = test
label1.place(x=0, y=0)

veheast = 0
vehwest = 0
vehnorth = 0
vehsouth = 0

def act():
    global veheast
    f_types = [('Jpg Files', '*.jpg')]
    filename1 = filedialog.askopenfilename(filetypes=f_types)
    im = cv2.imread(filename1)
    bbox, label, conf = cv.detect_common_objects(im)
    output_image = draw_bbox(im, bbox, label, conf)
    plt.imshow(output_image)
    plt.show()
    print('Number of objects in the image is ' + str(len(label)))
    messagebox.showinfo("Count", str(len(label)))
    veheast = int(str(len(label)))

def act1():
    global vehwest
    f_types = [('Jpg Files', '*.jpg')]
    filename1 = filedialog.askopenfilename(filetypes=f_types)
    im = cv2.imread(filename1)
    bbox, label, conf = cv.detect_common_objects(im)
    output_image = draw_bbox(im, bbox, label, conf)
    plt.imshow(output_image)
    plt.show()
    print('Number of objects in the image is ' + str(len(label)))
    messagebox.showinfo("Count", str(len(label)))
    vehwest = int(str(len(label)))

def act2():
    global vehnorth
    f_types = [('Jpg Files', '*.jpg')]
    filename1 = filedialog.askopenfilename(filetypes=f_types)
    im = cv2.imread(filename1)
    bbox, label, conf = cv.detect_common_objects(im)
    output_image = draw_bbox(im, bbox, label, conf)
    plt.imshow(output_image)
    plt.show()
    print('Number of objects in the image is ' + str(len(label)))
    messagebox.showinfo("Count", str(len(label)))
    vehnorth = int(str(len(label)))

def act3():
    global vehsouth
    f_types = [('Jpg Files', '*.jpg')]
    filename1 = filedialog.askopenfilename(filetypes=f_types)
    im = cv2.imread(filename1)
    bbox, label, conf = cv.detect_common_objects(im)
    output_image = draw_bbox(im, bbox, label, conf)
    plt.imshow(output_image)
    plt.show()
    print('Number of objects in the image is ' + str(len(label)))
    messagebox.showinfo("Count", str(len(label)))
    vehsouth = int(str(len(label)))

    if len(label) > 0:
        root = tk.Toplevel()
        root.title("Traffic Time Saver - Signal")
        root.geometry('700x600')
        root['background'] = 'pink'

        btn1 = tk.Button(root, text="North")
        btn1.place(relx=0.43, rely=0.30)

        btn2 = tk.Button(root, text="South")
        btn2.place(relx=0.43, rely=0.60)

        btn3 = tk.Button(root, text="East")
        btn3.place(relx=0.57, rely=0.45)

        btn4 = tk.Button(root, text="West")
        btn4.place(relx=0.30, rely=0.45)

        while True:
            for i in range(0, 20):
                btn1.config(background='green')
                btn2.config(background='red')
                btn3.config(background='red')
                btn4.config(background='red')
                btn1.update()
                time.sleep(veheast)

                btn1.config(background='red')
                btn2.config(background='green')
                btn2.update()
                time.sleep(vehwest)

                btn2.config(background='red')
                btn3.config(background='green')
                btn3.update()
                time.sleep(vehnorth)

                btn3.config(background='red')
                btn4.config(background='green')
                btn4.update()
                time.sleep(vehsouth)
                btn4.config(background='red')

# Buttons
tk.Button(winadmin, text=" Upload North Traffic Image ", font='Verdana 10 bold',
          bg="blue", fg="white", command=act).place(x=240, y=150)

tk.Button(winadmin, text=" Upload South Traffic Image ", font='Verdana 10 bold',
          bg="blue", fg="white", command=act1).place(x=240, y=220)

tk.Button(winadmin, text=" Upload East Traffic Image  ", font='Verdana 10 bold',
          bg="blue", fg="white", command=act2).place(x=240, y=290)

tk.Button(winadmin, text=" Upload West Traffic Image  ", font='Verdana 10 bold',
          bg="blue", fg="white", command=act3).place(x=240, y=360)

winadmin.mainloop()
